
// Client-side interactions for the site
const quartiers = ["Kigobe", "Rohero", "Kabondo", "Kinindo", "Nyakabiga", "Ngagara", "Mutanga", "Musaga"];
const provinces = ["Gitega", "Ngozi", "Kayanza", "Rumonge", "Bururi", "Cibitoke", "Makamba"];
const DEFAULT_LISTINGS = [{"id": "kiriri-1", "title": "Maison Kiriri", "price": 850000000, "location": "Kigobe", "province": "Bujumbura", "type": "Maison", "beds": 3, "photos": ["assets/img1.jpg"], "desc": "3 chambres • Jardin"}, {"id": "mutanga-1", "title": "Villa Mutanga", "price": 1200000000, "location": "Mutanga", "province": "Bujumbura", "type": "Villa", "beds": 5, "photos": ["assets/img2.jpg"], "desc": "Piscine • Finitions premium"}];

function el(id){return document.getElementById(id);}

// render chips
function renderChips(){
  const qWrap = document.getElementById('quartierList');
  quartiers.forEach(q=>{
    const b = document.createElement('div'); b.className='btn'; b.textContent=q;
    b.addEventListener('click', ()=>{ filterBy('location', q); highlightChip(b); });
    qWrap.appendChild(b);
  });
  const pWrap = document.getElementById('provinceList');
  provinces.forEach(p=>{
    const b = document.createElement('div'); b.className='btn'; b.textContent=p;
    b.addEventListener('click', ()=>{ filterBy('province', p); highlightChip(b); });
    pWrap.appendChild(b);
  });
}

// sample listings (loaded from localStorage or defaults)
function getListings(){ return JSON.parse(localStorage.getItem('ciza_listings')||JSON.stringify(DEFAULT_LISTINGS)); }
function saveListings(arr){ localStorage.setItem('ciza_listings', JSON.stringify(arr)); }

function renderListings(list){
  const wrap = document.getElementById('annoncesList'); wrap.innerHTML='';
  list.forEach(it=>{
    const d = document.createElement('div'); d.className='card'; d.setAttribute('data-location', it.location);
    d.innerHTML = '<img src="'+it.photos[0]+'"><div class="card-body"><h3>'+it.title+'</h3><p>'+new Intl.NumberFormat('fr-FR').format(it.price)+' BIF</p><p style="color:#666">'+it.desc+'</p></div>';
    wrap.appendChild(d);
  });
}

function filterBy(field, value){
  const all = getListings();
  const filtered = all.filter(x=> (x[field]||'').toLowerCase().includes(value.toLowerCase()));
  renderListings(filtered);
}

function highlightChip(btn){
  // remove active from siblings
  btn.parentNode.querySelectorAll('.btn').forEach(b=>b.classList.remove('active-btn'));
  btn.classList.add('active-btn');
}

// testimonials
function renderTestimonials(){
  const el = document.getElementById('testimonials');
  const t = JSON.parse(localStorage.getItem('ciza_testimonials')||'[]');
  if(!t.length){
    el.innerHTML = '<div class="testimonial">Aucun témoignage pour le moment.</div>'; return;
  }
  el.innerHTML = '';
  t.forEach(tt=>{ const div=document.createElement('div'); div.className='testimonial'; div.textContent = tt.name + ' — ' + tt.text; el.appendChild(div); });
}

// admin functions (used in admin.html)
function addListingFromAdmin(listing){
  const arr = getListings();
  arr.push(listing);
  saveListings(arr);
}

// bootstrap on load
document.addEventListener('DOMContentLoaded', ()=>{
  renderChips();
  renderListings(getListings());
  renderTestimonials();
});
